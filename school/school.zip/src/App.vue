<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {};
</script>

<style lang="less">
 @import "./style/common.less";
 @import "./style/iconfont.less";

 
</style>
